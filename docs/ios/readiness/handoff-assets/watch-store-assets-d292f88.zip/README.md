# Timbre — Apple Watch screenshots

This bundle contains two native 416 × 496 PNG screenshots for each of the 50 supported App Store listing locales.
Use the matching locale folder in the Apple Watch screenshot slot. Metronome is first; Today is second.
The images have no alpha channel and are unchanged copies of the verified native simulator captures.
Regional variants intentionally reuse the matching app-language image. Malay, Odia and Traditional Chinese listings
use the explicitly recorded English app fallback; this does not claim those app UI languages exist.

`manifest.json` records every file hash, source capture, language mapping and GitHub Actions provenance.
The Today activity list is vertically scrollable and continues below the captured viewport.
This is the Watch screenshot portion of the release material, not a complete App Store submission package.
Physical haptics, wrist-down behavior and device synchronization still require hardware verification.
