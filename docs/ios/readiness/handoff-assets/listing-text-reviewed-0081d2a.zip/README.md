# Timbre — reviewed localized store text

Each of the 50 locale folders contains exact UTF-8 field values from the reviewed store payloads. Text files can be
used for the matching App Store Connect fields. `iap-localizations.json` contains the three product names and descriptions;
`caption-text.json` contains the reviewed screenshot and preview captions. It contains text, not finished images or video.

`manifest.json` binds every exported field to its file hash and the reviewed source payload. Game Center metadata is
omitted because the release configuration disables that optional feature. Account/product setup and the remaining
native/media checks still need to complete before submission.
